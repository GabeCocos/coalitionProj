How to Run
1. Download or unzip the project files
2. Open `index.html` in a modern web browser
3. The dashboard will automatically fetch data from the API and render the 

Notes
- Source files are included as requested (no minified-only submission)
- Chart.js is loaded via CDN
- Error handling is included for failed API requests or missing patient data
- The implementation intentionally avoids over-engineering or unnecessary features

Author
Gabriel Cocos
